class StepsGeneratingException(Exception):
	pass